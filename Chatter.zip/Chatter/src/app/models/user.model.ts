export class UserModel {

    constructor(
      public id?: number,
      public name?: string,
      public major?: string,
      public email?: string) {
  
    }
  
  }
  