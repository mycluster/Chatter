import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'UserClasses',
  templateUrl: './user-classes.component.html',
  styleUrls: ['./user-classes.component.scss']
})
export class UserClassesComponent implements OnInit {
  user: any;
  message: string;
  noteName: string;
  classes: string[];
  form: any;
  submitted: boolean = false;
  constructor() { }

  ngOnInit() {
    this.classes = ['Class1', 'English101', 'Finance101']
  }

  onSubmit(form: any){
    this.submitted = true;
    this.form = form;
  }

}
