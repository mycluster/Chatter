import { Component, OnInit } from '@angular/core';
import { UserModel } from '../models/user.model';
import { FormGroup } from '@angular/forms';
import { FormControl } from '@angular/forms';
import { Validators } from '@angular/forms';
import { ValidationService } from '../services/validation.service';

@Component({
    selector: 'EditUser',
    templateUrl: './edit-user.component.html',
    styleUrls: ['./edit-user.component.scss']
})
export class EditUserComponent implements OnInit {
    model: UserModel;
    userForm: FormGroup;
    formModelProps = [];
    submitted: boolean;

    constructor() { }

    ngOnInit() {
        this.model = new UserModel(18, 'Dr IQ', 'Computer Science',  'iq@superhero.com');

        const formModel = {};
        let validators = [ Validators.required ];
        for (const prop of Object.keys(this.model)) {
            if (prop.indexOf('email') !== -1) validators.push(ValidationService.emailValidator);
            formModel[prop] = new FormControl(this.model[prop], validators);
            this.formModelProps.push(prop);
        }
        this.userForm = new FormGroup(formModel);
    }

    submit() {
        this.submitted = true;
    }

}
