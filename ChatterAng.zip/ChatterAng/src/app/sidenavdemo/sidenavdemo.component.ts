import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sidenavdemo',
  templateUrl: './sidenavdemo.component.html',
  styleUrls: ['./sidenavdemo.component.css']
})
export class SidenavdemoComponent implements OnInit {
  sidebarVisible;
  notesVisible;
  groupsVisible;
  sidebarButtonText;
  constructor() { 
    this.sidebarVisible = false;
    this.groupsVisible = false;
    this.notesVisible = false;
    this.sidebarButtonText = "Show Sidebar";
  }

  ngOnInit() {
  }

  toggleSidebar(){
    if (this.sidebarVisible = !this.sidebarVisible){
      this.sidebarButtonText = "Show Sidebar";
    }
    else {
      this.sidebarButtonText = "Hide Sidebar"
    }
  }

  toggleNotes(){
    if (this.notesVisible = !this.notesVisible){
      // this.sidebarButtonText = "Show Sidebar";
    }
    else {
      // this.sidebarButtonText = "Hide Sidebar"
    }
  }

  toggleGroups(){
    if (this.groupsVisible = !this.groupsVisible){
      // this.sidebarButtonText = "Show Sidebar";
    }
    else {
      // this.sidebarButtonText = "Hide Sidebar"
    }
  }

}
