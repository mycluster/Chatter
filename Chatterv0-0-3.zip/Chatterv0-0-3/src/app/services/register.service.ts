import { RegisterModel } from './../models/register.model';
import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';


@Injectable()
export class RegisterService {
  constructor(
    private http: HttpClient,
    ){}
  httpOptions={
    headers: new HttpHeaders({'Content-Type': 'application/json'})
  };

  register(registration: RegisterModel){
    let body = new HttpParams(); //declares the body as HttpParams so that the user data can be sent as parameters
    let headers = new HttpHeaders().set('Content-Type', 'application/x-www-form-urlencoded');

    //the following lines set the parameters to the respective fields from the registration model
    body = body.set('first_name', registration.first_name);
    body = body.set('last_name', registration.last_name);
    body = body.set('username', registration.username);
    body = body.set('email', registration.email);
    body = body.set('password', registration.password);
   
    //sends an http post request to the servlet
    return this.http.post(`http://localhost:8089/chatterJava/Register`, body, {headers: headers});
  }

}