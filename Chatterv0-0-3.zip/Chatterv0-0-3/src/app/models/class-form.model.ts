export interface Class_Form{
    username:string;
    classname:string;
    subject:string;
}