export interface User_Classes{
    classes:string;
}