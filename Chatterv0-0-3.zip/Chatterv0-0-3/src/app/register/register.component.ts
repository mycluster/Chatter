import { RegisterService } from './../services/register.service';
import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.scss']
})
export class RegisterComponent implements OnInit {
  registerForm: FormGroup; //declares the form group fro use in this component
  passwordMatch: boolean; //used for displaying/hiding a section for notifying the user that they inputted non-matching passwords
  constructor(
    private registerService: RegisterService,
    private formBuilder: FormBuilder
  ) { }

  ngOnInit() {
    this.passwordMatch = true;
    this.registerForm = this.formBuilder.group({
      Fname: [''], //the person's first name
      Lname: [''], //the person's last name
      username: [''], //the selected username
      email: [''], //the user's email
      password: [''], //a password for the user
      confirm_password: [''] //a password confirmation to ensure that the user can type two passwords the same
    });
  }

  register(){
    this.passwordMatch = true; //starts true
    if (this.registerForm.value["password"] == 
        this.registerForm.value["confirm_password"]){ //if password and confirm_password are the same
      this.registerService.register(this.registerForm.value).subscribe(); //calls the register service function register()
    }
    else{ //if the password and confirm_password do
      this.passwordMatch = false; //sets the passwordMatch variable to false
    }
  }
}
