import { Injectable } from '@angular/core';
import { Registration } from "../models/registration";
import { HttpClient, HttpHeaders, HttpParams} from '@angular/common/http';

@Injectable()
export class RegisterService {
    constructor(private http:HttpClient) { } 
httpOptions={
    headers: new HttpHeaders({'Content-Type': 'application/json' })
};

register(registration: Registration) {
    let body = new HttpParams();
    let headers = new HttpHeaders().set('Content-Type', 'application/x-www-form-urlencoded');

    let username = 'username='+registration.username;
    let email = 'email='+registration.email;
    let password = 'password='+registration.password;
    let confpassword = 'confirm_password='+registration.confirm_password;
    let bod = username + email + password + confpassword;

    console.log(bod);
    return this.http.post(`http://localhost:8085/xhr_post/Index/Register`,bod,{headers:headers});
}

}