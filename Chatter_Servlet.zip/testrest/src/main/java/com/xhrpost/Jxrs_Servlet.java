package com.xhrpost;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class Jxrs_Servlet extends HttpServlet {
//	private static final Logger logger = Logger.getLogger(Jxrs_Servlet.class) 
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String uri = request.getRequestURL()
				.toString()
				.substring(31)
				.toLowerCase();
		String user = request.getParameter("username");
		String pass = request.getParameter("password");
		System.out.println("URI: " + uri);
		System.out.println("User is " + user);
		System.out.println("Password is " + pass);
		
		
	 }
}

