export interface CheckPasswordModel{
    doesPass : string;
}