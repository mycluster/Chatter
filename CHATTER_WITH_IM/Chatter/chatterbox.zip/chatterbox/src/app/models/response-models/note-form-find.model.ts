export interface NoteFormFindModel{
    note:string;
}