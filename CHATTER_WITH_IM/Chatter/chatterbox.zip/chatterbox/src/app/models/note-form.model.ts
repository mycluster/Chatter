export interface NoteFormModel{
    notename:string;
    note:string
}