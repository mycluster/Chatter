export interface UserClassesModel{
    classes:string;
}