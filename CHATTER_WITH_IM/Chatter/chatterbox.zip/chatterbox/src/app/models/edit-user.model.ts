export interface EditUserModel{
    name:string,
    major:string,
    email:string
}