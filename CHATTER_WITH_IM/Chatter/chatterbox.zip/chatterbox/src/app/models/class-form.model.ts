export interface ClassFormModel{
    username:string;
    classname:string;
}