export enum DialogUserType {
    NEW,
    EDIT
}