export enum Action {
    NEWMESSAGE,
    EDIT,
    SWITCHCONVO,
    JOINED,
    LEFT,
    RENAME
  }